package con_flyweight;

import java.util.HashMap;
import java.util.Map;

public class FabricaGunter {
    private static final Map<String, Gunter> pool = new HashMap<>();

    public static Gunter obtenerGunter(String tipo) {
        Gunter gunter = pool.get(tipo);
        if (gunter == null) {
            gunter = new Gunter(tipo);
            pool.put(tipo, gunter);
        }
        return gunter;
    }

    public static int getCantidadObjetos() {
        return pool.size();
    }
}
