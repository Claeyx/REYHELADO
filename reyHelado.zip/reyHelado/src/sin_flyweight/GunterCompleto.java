package sin_flyweight;

public class GunterCompleto {
    private final String tipo;
    private final String sonido;
    private final int x;
    private final int y;

    public GunterCompleto(String tipo, int x, int y) {
        this.tipo = tipo;
        this.sonido = "Wenk!";
        this.x = x;
        this.y = y;
    }

    public void activar() {
        System.out.println(sonido + " Gunter " + tipo + " en posición (" + x + ", " + y + ")");
    }
}
