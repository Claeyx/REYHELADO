package sin_flyweight;

import Util.MemoryDisplay;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainSinFlyweight {
    public static void main(String[] args) {
        int totalSimulados = 100000;
        List<GunterCompleto> ejercito = new ArrayList<>();
        Random random = new Random();

        long memoriaInicial = MemoryDisplay.memoriaUsadaMB();

        for (int i = 0; i < totalSimulados; i++) {
            String tipo = (i % 2 == 0) ? "Normal" : "Con sombrero";
            int x = random.nextInt(100);
            int y = random.nextInt(100);

            ejercito.add(new GunterCompleto(tipo, x, y));
        }

        for (int i = 0; i < 5; i++) {
            ejercito.get(i).activar();
        }

        long memoriaFinal = MemoryDisplay.memoriaUsadaMB();

        System.out.println("...");
        System.out.println("Total de pingüinos creados sin Flyweight: " + ejercito.size());
        System.out.println("Memoria consumida: " + (memoriaFinal - memoriaInicial) + " MB");
    }
}
